#!/usr/bin/env python
# encoding=utf-8

"""
This is sphinx's configuration
"""

sphinx = {'host': '10.123.4.212', 'port': 9312}
weight = {'title': 50, 'content': 1}

